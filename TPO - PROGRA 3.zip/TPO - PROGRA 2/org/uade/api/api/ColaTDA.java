package org.uade.api.api;

public interface ColaTDA {
    void inicializarCola();

    void acolar(int x);

    void desacolar(); //Elimina el primer elementp ingresado

    int primero(); //Muestra el primer elemento ingresado

    boolean colaVacia();

    void eliminarValor(int x);
}