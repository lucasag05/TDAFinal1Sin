package org.uade.api.api;

public interface DiccionarioSimpleTDA {
    void InicializarDiccionario();
    void Agregar(int clave, int valor);
    void Eliminar(int clave);
    int Recuperar(int clave); //Obtiene valor de una clave
    ConjuntoTDA Claves(); //Hace un listado con las claves

}
