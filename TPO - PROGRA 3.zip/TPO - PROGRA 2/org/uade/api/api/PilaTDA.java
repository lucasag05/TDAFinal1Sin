package org.uade.api.api;

public interface PilaTDA {
    void inicializarPila();
    void apilar(int x);
    void desapilar(); //Borra el ultimo elemento ingresado
    int tope(); //Muestra el ultimo elemento ingresado
    boolean pilaVacia();

}
