package org.uade.api.api;

public interface ConjuntoTDA {
    void inicializarConjunto();
    void agregar(int x);
    int elegir(); //Elige un valor al azar y lo retorna
    void sacar(int x);
    boolean pertenece(int x); //Comprueba si un elemento esta o no
    boolean conjuntoVacio();
}
