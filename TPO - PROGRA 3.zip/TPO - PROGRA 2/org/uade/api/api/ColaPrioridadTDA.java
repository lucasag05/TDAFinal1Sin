package org.uade.api.api;

public interface ColaPrioridadTDA {

    void inicializarCola();
    void acolarPrioridad(int x, int p);
    void desacolar(); //Elimina el primer elemento ingresado y su prioridad tmb
    int primero(); //Muestra el primer elemento ingresado
    boolean colaVacia();
    int prioridad(); //Obtiene la prioridad del primer elemento

}
