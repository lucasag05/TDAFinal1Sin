package org.uade.api.impl;

public class NodoPrioridad {
    int info ;
    int prioridad;
    NodoPrioridad sig ;
}
