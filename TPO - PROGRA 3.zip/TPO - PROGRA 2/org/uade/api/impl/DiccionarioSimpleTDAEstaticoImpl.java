package org.uade.api.impl;

import org.uade.api.api.ConjuntoTDA;
import org.uade.api.api.DiccionarioSimpleTDA;
public class DiccionarioSimpleTDAEstaticoImpl implements DiccionarioSimpleTDA {
    class Elemento{
        int clave;
        int valor;
    }
    Elemento[] elementos;
    int cant ;
    public void InicializarDiccionario () {
        cant = 0;
        elementos = new Elemento [100];
    }
    public void Agregar( int clave , int valor){
        int pos = Existe(clave);
        if ( pos == -1) {
            pos = cant ;
            elementos[ pos ]= new Elemento ();
            elementos[ pos ].clave = clave;
            cant ++;
        }
        elementos[pos].valor = valor;
    }
    private int Existe( int clave){
        int i= cant -1;
        while(i >=0 && elementos[i ].clave!= clave) {
            i --;
        }
        return i;
    }
    public void Eliminar( int clave) {
        int pos = Existe( clave);
        if ( pos != -1) {
            elementos[ pos ] = elementos[ cant -1];
            cant --;
        }
    }
    public int Recuperar( int clave) {
        int pos = Existe( clave);
        return elementos[ pos ]. valor;
    }
    public ConjuntoTDA Claves() {
        ConjuntoTDA c = new ConjuntoTDADinamicoImpl();
        c. inicializarConjunto();
        for ( int i =0; i < cant ; i ++) {
            c.agregar( elementos[i]. clave);
        }
        return c;
    }
}