package org.uade.api.impl;

public class Nodo {
    int info ;
    Nodo sig ;
}
