package org.uade.api.impl;

import org.uade.api.api.PilaTDA;

public class PilaTDAEstaticaImpl implements PilaTDA {
    int[] array;
    int i;

    @Override
    public void inicializarPila() {
        array = new int[100];
        i = 0;
    }

    @Override
    public void apilar(int x) {
        array[i] = x;
        i ++;
    }

    @Override
    public void desapilar() {
        i --;
    }

    @Override
    public int tope() {
        return array[i-1];
    }

    @Override
    public boolean pilaVacia() {
        return i == 0;
    }

}
