package org.uade.api.impl;

import org.uade.api.api.ColaTDA;

public class ColaTDAEstaticaImpl implements ColaTDA {
    int[] array;
    int inicio;
    int fin;

    @Override
    public void eliminarValor(int x) {
        int nuevoFin = inicio; // Nuevo índice para reconstruir la cola

        for (int i = inicio; i < fin; i++) {
            if (array[i] != x) {
                array[nuevoFin] = array[i];
                nuevoFin++;
            }
        }

        fin = nuevoFin;
    }

    @Override
    public void inicializarCola() {
        array = new int[100];
        inicio = 0;
        fin = 0;
    }

    // Añadimos un elemento al final de la cola
    @Override
    public void acolar(int x) {
        array[fin] = x;
        fin ++;
    }

    // Removemos el primer elemento de la cola
    @Override
    public void desacolar() {
        if (!colaVacia()){
            inicio ++;
        }
    }

    // Devolvemos el primer elemento de la cola
    @Override
    public int primero() {
        return array[inicio];
    }

    // Verificamos si la cola está vacía
    @Override
    public boolean colaVacia() {
        return inicio == fin;
    }
}
