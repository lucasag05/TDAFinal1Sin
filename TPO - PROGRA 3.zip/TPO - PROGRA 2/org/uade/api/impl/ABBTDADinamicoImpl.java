package org.uade.api.impl;

import org.uade.api.api.ABBTDA;

public class ABBTDADinamicoImpl implements ABBTDA {
    class NodoABB{
        int info;
        ABBTDA hijoIzq;
        ABBTDA hijoDer;
    }
    NodoABB raiz;

    @Override
    public void inicializarArbol() {
        raiz = null;
    }

    @Override
    public int raiz() {

        return raiz.info;
    }

    @Override
    public ABBTDA hijoIzq() {

        return raiz.hijoIzq;
    }

    @Override
    public ABBTDA hijoDer() {

        return raiz.hijoDer;
    }

    @Override
    public void agregar(int x) {
        if (raiz == null){
            raiz = new NodoABB();
            raiz.info = x;
            raiz.hijoIzq = new ABBTDADinamicoImpl();
            raiz.hijoIzq.inicializarArbol();
            raiz.hijoDer = new ABBTDADinamicoImpl();
            raiz.hijoDer.inicializarArbol();
        }
        else if (raiz.info > x )
            raiz.hijoIzq.agregar(x);
        else if (raiz.info < x)
            raiz.hijoDer.agregar(x);
    }

    @Override
    public void eliminar(int x) {
        if (raiz != null) {
            if (raiz.info == x && raiz.hijoIzq.arbolVacio() &&
                    raiz.hijoDer.arbolVacio()) {
                raiz = null;
            }
            else if (raiz.info < x){
                raiz.hijoDer.eliminar(x);
            }
            else{
                raiz.hijoIzq.eliminar(x);
            }
        }
    }

    @Override
    public boolean arbolVacio() {

        return (raiz == null);
    }
}

