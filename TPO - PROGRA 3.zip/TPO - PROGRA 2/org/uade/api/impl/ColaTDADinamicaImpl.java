package org.uade.api.impl;

import org.uade.api.api.ColaTDA;

public class ColaTDADinamicaImpl implements ColaTDA {
    Nodo primero;
    Nodo ultimo;

    @Override
    public void inicializarCola() {
        primero = null ;
        ultimo = null ;
    }

    // Añadimos un elemento al final de la cola
    @Override
    public void acolar(int x) {
        Nodo aux = new Nodo ();
        aux.info = x;
        aux.sig = null;
// Si la cola no est´a vac´ıa
        if ( ultimo != null)
        ultimo. sig = aux ;
        ultimo = aux ;
// Si la cola estaba vac´ıa
        if ( primero == null)
        primero = ultimo;

    }

    // Removemos el primer elemento de la cola
    @Override
    public void desacolar() {
        primero = primero. sig ;
// Si la cola queda vac´ıa
        if ( primero == null)
        ultimo = null;

    }

    // Devolvemos el primer elemento de la cola
    @Override
    public int primero() {
        return primero.info ;
    }

    // Verificamos si la cola está vacía
    @Override
    public boolean colaVacia() {
        return (ultimo == null) ;
    }

    @Override
    public void eliminarValor(int x) {
    }


}
