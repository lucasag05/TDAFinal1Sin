package org.uade.api.impl;

import org.uade.api.api.ColaPrioridadTDA;

public class ColaPrioridadTDAEstaticaImpl implements ColaPrioridadTDA {
    int [] elementos;
    int [] prioridades;
    int indice; //Siempre es uno mas que el ultimo elemento

    public void inicializarCola () {
        indice = 0;
        elementos = new int [100];
        prioridades = new int [100];
    }
    public void acolarPrioridad ( int x, int prioridad){
        int j = indice;
        for ( ; j >0 && prioridades[j -1] >= prioridad; j -- ){
            elementos[j] = elementos[j -1];
            prioridades[ j] = prioridades[j -1];
        }
        elementos[j] = x ;
        prioridades[j] = prioridad;
        indice++;
    }
    public void desacolar() {
        indice --;
    }
    public int primero() {
        return elementos[ indice -1];
    }
    public boolean colaVacia (){
        return ( indice == 0);
    }
    public int prioridad() {
        return prioridades[ indice -1];
    }
}